﻿using System.Text;

namespace Day03Solution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region problem 1
            //Console.Write("Enter string you want to convert :");
            //string Input = Console.ReadLine();
            //int number;
            //bool flag = int.TryParse(Input, out number);
            //Console.WriteLine(number);
            //Console.WriteLine(flag);


            //try
            //{
            //    int result = Convert.ToInt32(Input);
            //    Console.WriteLine(result);
            //}
            //catch(Exception ex)
            //{
            //    Console.WriteLine($"Convert.Int32 failed {ex.Message}");
            //}
            ///*
            // * int.parse()=> throw an excption when input is null , ArgumentNullException is raised when a null value is passed to int.Parse
            // * int.Parse is strictly designed to convert valid string representations of integers.
            // * Since null is not a valid string, it cannot handle it
            // * --------------------------------------------------------
            // * Convert.ToInt32()=>Returns 0 when the input is null.
            // * it has built-in handling for null inputs. Internally, it checks for null and returns 0 without throwing an exception.
            // * */
            #endregion

            #region problem 2
            //Console.Write("Please enter number: ");
            //string  Input = Console.ReadLine();

            //if (int.TryParse(Input, out int  Number))
            //{
            //    Console.WriteLine($"Valid number :{Number}");
            //}else
            //{
            //    Console.WriteLine("Input is invalid Integer");
            //}
            ///*
            // * TryParse is recommended in user-facing applications for its robustness, efficiency,
            // * and ability to handle invalid inputs gracefully without relying on exception handling, making it more user-friendly and performant
            // * */
            #endregion

            #region problem 3
            //object obj = new object();
            //int x = 5;
            //obj = x;
            //Console.WriteLine($"integer object = {obj}");
            //Console.WriteLine($"hashed integer object = {obj.GetHashCode()}");
            //string word = "sara";
            //obj = word;
            //Console.WriteLine($"string object = {obj}");
            //Console.WriteLine($"hashed string object = {obj.GetHashCode()}");
            //double y = 4.5;
            //obj = y;
            //Console.WriteLine($"double object = {obj}");
            //Console.WriteLine($"hashed double object = {obj.GetHashCode()}");
            ///*
            // * The GetHashCode() method is primarily used in hash-based collections to optimize storage and retrieval.
            // * It provides a numerical representation of an object's state that can be used to group and identify objects efficiently.
            // * Its reliability in ensuring correct object behavior depends on being consistent with the Equals() method.
            // * */
            #endregion

            #region problem 4
            //int[] numbers = { 1, 2, 3, 4, 5 };
            //int[] copyNumbers = numbers;
            //numbers[0] = 80;
            //Console.WriteLine("Original array : " + numbers[0] + " copy array : " + copyNumbers[0]);

            //// reference equality means that two references point to the same object instance in memory
            #endregion

            #region problem 5
            //string word = "Hello , ";
            //string NewWord = word + "Hi Willy";
            //Console.WriteLine($"Original word : {word} And its hashed value : {word.GetHashCode()}");
            //Console.WriteLine($"New word : {NewWord} And its hashed value : {NewWord.GetHashCode()}");
            ///*
            // *In C#, the string type is immutable, meaning once a string object is created, its value cannot be changed. 
            // *Any operation that appears to modify a string (e.g., concatenation, replacement) actually creates a new string object instead.
            // */
            #endregion

            #region problem 6
            //StringBuilder word = new StringBuilder("hello, ");
            //Console.WriteLine($"Original word : {word} , AND its hashed value : {word.GetHashCode()}");
            //word.Append("Hi Willy");
            //Console.WriteLine($"Modification word : {word} , AND its hashed value : {word.GetHashCode()}");
            ////StringBuilder, which is mutable and optimized for such operations (concatenation , replacement ...)
            ////This design choice ensures robust, predictable, and secure behavior in string handling.
            #endregion

            #region problem 7
            /*
             * Strings in C# are immutable meaning any operation that modifies a string (e.g., concatenation, replacement) 
             * creates a new string object in memory
             * This leads to Increased memory allocation , and Performance overhead due to garbage collection of intermediate string objects.
             * The StringBuilder class uses an internal mutable buffer to store characters.
             * This buffer can grow as needed without creating new objects for every modification
             * Operations like Append, Insert, and Replace directly modify the buffer, making it significantly more efficient for repetitive modifications
             * By avoiding frequent allocations of new string objects, StringBuilder reduces the burden on the garbage collector.
             */
            #endregion

            #region problem 8
            //Console.Write("Please enter first operand : ");
            //int Number1 = int.Parse(Console.ReadLine());
            //Console.Write("Please enter second operand : ");
            //int Number2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("Sum = " + Number1 + " + " + Number2 + " = " + (Number1 + Number2));
            //Console.WriteLine($"Sum = {Number1} + {Number2} = {Number1 + Number2}");
            //Console.WriteLine("Sum = {0} + {1}= {2}", Number1, Number2, (Number1 + Number2));//string formate
            ////String Interpolation ($) is the most commonly used method in modern C# programming because
            ////It is the most readable and concise , It simplifies string construction by embedding expressions directly
            ////avoids the verbosity and complexity of composite formatting and the potential errors of concatenation.
            #endregion

            #region problem 9
            //StringBuilder SB = new StringBuilder();
            //SB.AppendLine("sara Mahmoud");
            //SB.Replace("Mahmoud", "Omar");//sara omar
            //SB.Insert(5,"Mahmoud ");//sara mahmoud omar
            //Console.WriteLine(SB);
            //SB.Remove(12,5 );
            //Console.WriteLine(SB);
            ///*
            // * Unlike strings, which are immutable, StringBuilder objects allow direct modification of their internal character buffer.
            // * This eliminates the need to create a new object for each change, making operations like appending, inserting, and removing much faster.
            // * Strings:Each modification (e.g., concatenation) creates a new string object.This leads to frequent memory allocation and garbage collection for temporary objects.
            // * StringBuilder:Maintains a resizable buffer to accommodate changes without reallocating memory unless the buffer size is exceeded.
            // * */
            #endregion
        }

    }
}

﻿namespace Day05Solution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region problem 1
            //try
            //{
            //    Console.Write("Enter First Number : ");
            //    int number1;
            //    bool falg1 = int.TryParse(Console.ReadLine(), out number1);
            //    Console.Write("Enter second Number : ");
            //    int number2;
            //    bool falg2 = int.TryParse(Console.ReadLine(), out number2);
            //    int result = number1 / number2;

            //}
            //catch(DivideByZeroException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Operation Complete");
            //}

            #endregion

            #region problem 2
            //int x = GetPositiveInteger("Enter a positive integer for X: ");
            //int y = GetPositiveInteger("Enter a positive integer for Y (greater than 1): ", 2);

            //Console.WriteLine($"You entered X: {x} and Y: {y}");

            #endregion

            #region problem 3
            //int? nullableInt = null;
            //int defaultValue = nullableInt ?? 42;

            //Console.WriteLine($"Nullable Integer: {nullableInt}");
            //Console.WriteLine($"Value after null-coalescing: {defaultValue}");

            //if (nullableInt.HasValue)
            //    Console.WriteLine($"Nullable has value: {nullableInt.Value}");
            //else
            //    Console.WriteLine("Nullable does not have a value.");
            #endregion

            #region problem 4
            //int[] numbers = new int[9];
            //try
            //{
            //    Console.WriteLine(numbers[10]);
            //}
            //catch (IndexOutOfRangeException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            #endregion

            #region problem 5
            //int[,] Numbers = new int[3, 3];

            //Console.WriteLine("Enter 9 elements for a 3x3 array:");
            //for (int i = 0; i < Numbers.GetLength(0); i++)
            //{
            //    for (int j = 0; j < Numbers.GetLength(1); j++)
            //    {
            //        Console.Write($"Element [{i},{j}]: ");
            //        Numbers[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //for (int i = 0; i < Numbers.GetLength(0); i++)
            //{
            //    int rowSum = 0, colSum = 0;
            //    for (int j = 0; j < Numbers.GetLength(1); j++)
            //    {
            //        rowSum += Numbers[i, j];
            //        colSum += Numbers[j, i];
            //    }
            //    Console.WriteLine($"Sum of row {i}: {rowSum}");
            //    Console.WriteLine($"Sum of column {i}: {colSum}");
            //}
            #endregion

            #region problem 6
            //int[][] jaggedArray = new int[3][];

            //for (int i = 0; i < jaggedArray.Length; i++)
            //{
            //    Console.Write($"Enter size for row {i + 1}: ");
            //    int size = int.Parse(Console.ReadLine());
            //    jaggedArray[i] = new int[size];

            //    Console.WriteLine($"Enter {size} elements for row {i + 1}:");
            //    for (int j = 0; j < size; j++)
            //    {
            //        Console.Write($"Element {j + 1}: ");
            //        jaggedArray[i][j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("Jagged array contents:");
            //for (int i = 0; i < jaggedArray.Length; i++)
            //{
            //    Console.WriteLine($"Row {i + 1}: {string.Join(", ", jaggedArray[i])}");
            //}
            #endregion

            #region problem 7
            //Console.Write("Enter a value (or leave blank): ");
            //string? input = Console.ReadLine();
            //string? nullableString = string.IsNullOrWhiteSpace(input) ? null : input;
            //Console.WriteLine("Value: " + nullableString!);
            #endregion

            #region problem 8
            //int value = 42;
            //object boxed = value;
            //try
            //{
            //    int unboxed = (int)boxed;
            //    Console.WriteLine("Unboxed Value: " + unboxed);

            //    string invalidCast = (string)boxed;
            //}
            //catch (InvalidCastException ex)
            //{
            //    Console.WriteLine("Invalid cast: " + ex.Message);
            //}
            #endregion

            #region problem 9
            //SumAndMultiply(4, 5, out int sum, out int product);
            //Console.WriteLine($"Sum: {sum}, Product: {product}");
            #endregion

            #region problem 10
            //PrintString(message: "Hello, World!", repeat: 3);
            //PrintString("Default Repeat");
            #endregion

            #region problem 12
            //int?[]? numbers = null;
            //Console.WriteLine("Array Length: " + numbers?.Length);
            #endregion

            #region problem 13
            //Console.Write("Enter a day of the week: ");
            //string day = Console.ReadLine() ?? string.Empty;

            //int dayNumber = day.ToLower() switch
            //{
            //    "monday" => 1,
            //    "tuesday" => 2,
            //    "wednesday" => 3,
            //    "thursday" => 4,
            //    "friday" => 5,
            //    "saturday" => 6,
            //    "sunday" => 7,
            //    _ => 0 // Default case
            //};

            //Console.WriteLine($"Day Number: {dayNumber}");
            #endregion

            #region problem 14
            //int[] values = { 1, 2, 3 };
            //Console.WriteLine("Sum (Array): " + SumArray(values));
            //Console.WriteLine("Sum (Individual): " + SumArray(4, 5, 6));
            #endregion

            #region problem 15
            //Console.Write("Enter a positive integer: ");
            //int number = int.Parse(Console.ReadLine());
            //for (int i = 1; i <= number; i++)
            //{
            //    Console.Write(i + (i < number ? ", " : "\n"));
            //}
            #endregion

            #region problem 16
            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());
            //for (int i = 1; i <= 12; i++)
            //{
            //    Console.WriteLine($"{number} x {i} = {number * i}");
            //}
            #endregion

            #region problem 17
            //Console.Write("Enter a positive integer: ");
            //int number = int.Parse(Console.ReadLine());
            //for (int i = 2; i <= number; i += 2)
            //{
            //    Console.Write(i + (i < number - 1 ? ", " : "\n"));
            //}
            #endregion

            #region problem 18
            //Console.Write("Enter base: ");
            //int baseNumber = int.Parse(Console.ReadLine());
            //Console.Write("Enter exponent: ");
            //int exponent = int.Parse(Console.ReadLine());
            //Console.WriteLine($"{baseNumber}^{exponent} = {Math.Pow(baseNumber, exponent)}");
            #endregion

            #region problem 19
            //Console.Write("Enter a string: ");
            //string input = Console.ReadLine();
            //char[] chars = input.ToCharArray();
            //Array.Reverse(chars);
            //Console.WriteLine("Reversed: " + new string(chars));
            #endregion

            #region problem 20
            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());
            //string reversed = new string(number.ToString().ToCharArray().Reverse().ToArray());
            //Console.WriteLine($"Reversed: {reversed}");
            //#endregion

            //#region problem 21
            //Console.Write("Enter array elements (comma-separated): ");
            //int[] array = Array.ConvertAll(Console.ReadLine().Split(','), int.Parse);
            //int maxDistance = 0;

            //for (int i = 0; i < array.Length; i++)
            //{
            //    for (int j = i + 1; j < array.Length; j++)
            //    {
            //        if (array[i] == array[j])
            //        {
            //            maxDistance = Math.Max(maxDistance, j - i);
            //        }
            //    }
            //}

            //Console.WriteLine($"Longest distance: {maxDistance}");
            #endregion

            #region problem 21
            //Console.Write("Enter a sentence: ");
            //string sentence = Console.ReadLine();
            //string reversed = string.Join(" ", sentence.Split(' ').Reverse());
            //Console.WriteLine(reversed);
            #endregion

        }

        //static int GetPositiveInteger(string message , int minValue=1)
        //{
        //    int value;
        //    do
        //    {
        //        Console.Write(message);
        //        if (!int.TryParse(Console.ReadLine(), out value) || value < minValue)
        //        {
        //            Console.WriteLine($"Please enter a valid integer greater than or equal to {minValue}.");
        //        }
        //    } while (value < minValue);
        //    return value;
        //}


        //static void SumAndMultiply(int a, int b, out int sum, out int product)
        //{
        //    sum = a + b;
        //    product = a * b;
        //}

        //static void PrintString(string message, int repeat = 5)
        //{
        //    for (int i = 0; i < repeat; i++)
        //    {
        //        Console.WriteLine(message);
        //    }
        //}

        //static int SumArray(params int[] numbers)
        //{
        //    int sum = 0;
        //    foreach (var number in numbers)
        //    {
        //        sum += number;
        //    }
        //    return sum;
        //}
    }
}

﻿module Mymodule
let greet name = 
    printfn "Hello, %s!" name

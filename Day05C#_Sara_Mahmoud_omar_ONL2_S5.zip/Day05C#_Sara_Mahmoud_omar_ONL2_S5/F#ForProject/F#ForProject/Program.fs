﻿// For more information see https://aka.ms/fsharp-console-apps
open System
open Mymodule

//input/output
//create function
//let hello()=
////start writting in your function
//    printf "Enter your name : "
//    let name = Console.ReadLine()
//    //%i ->integers ,b->boolean , %f->float , %A->internal representation of things like tuples , %O-> represent Object
//    printfn "Hello ,: %s" name 
////call function
//hello()
//Console.ReadKey() |> ignore  //ignore input from user

//binding/mutable
//let bindStuff()=
//    let mutable weight=75
//    weight <- 50
//    printfn "Weight = %i"weight
//bindStuff()

//Functions
//let do_Funcs()=
////create function inside functions
//    let get_Sum (x:int, y:int) : int = //:int is optional return type
//        x+y
//    printfn "5 + 6 = %i" (get_Sum(5,6))

//do_Funcs()

//Recursive Function
//let  do_Funcs2()=
//     let rec factorial number=
//         if number<1 then 1
//         else number * factorial(number-1)
//     printf"factorial of 4! is %i " (factorial 4)
//do_Funcs2()

//List and lambada expression 
//let do_Funcs3()=
//     //created list
//    let rand_s=[2;3;4;5]
//    //use function called map that will perform calculations on each element of list and return a brand new list
//    //fun used to create lambada expression (function recieve value of x and for each value perfrom on it *2 
//    //and finally it recieve input of rand_s list
//    let rand_s2=List.map (fun x->x*2) rand_s
//    printf "elements of list2 after multyplying by 2 is %A" rand_s2
//    printf "elements of list1 after multyplying by 2 is %A" rand_s //not changed immutable
//    //we can use pipeline operator to nest functions call 
//    //filter keep only element in list that keep condition
//    [5;6;1;2;3]
//    |> List.filter (fun x-> (x%2=0))//this try to create list of items that are even [2 , 6]
//    |> List.map (fun x->x*3) //multiply every item filter in the above by 3 ==> [6 18]
//    //final operation to perform is to print everything
//    |>printfn "Even numbers multiplies by 3 %A"  //[18; 6]
//    //compostion function
//    let mult_num x=x*3
//    let add_num y=y+5
//    let mult_add=mult_num >> add_num
//    let add_mult= mult_num <<add_num
//    printfn "mult then add : %i" (mult_add 10) //35
//    printfn "add then mult : %i" (add_mult 10) //45
//do_Funcs3()
//greet "sara"
 

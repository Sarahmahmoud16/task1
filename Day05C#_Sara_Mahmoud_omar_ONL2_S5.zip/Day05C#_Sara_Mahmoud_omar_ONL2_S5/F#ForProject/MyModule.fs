module MyModule

let greet name = 
    printfn "Hello, %s!" name

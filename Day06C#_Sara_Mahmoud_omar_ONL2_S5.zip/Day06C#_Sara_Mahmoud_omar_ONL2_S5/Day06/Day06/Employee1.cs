﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day06;
    public struct Employee1
    {
        private int EmpId;
        private string Name;
        private double Salary;

        public string GetName() => Name;
        public void SetName(string name) => Name = name;

        public double GetSalary() => Salary;
        public void SetSalary(double salary) => Salary = salary;
    }
 


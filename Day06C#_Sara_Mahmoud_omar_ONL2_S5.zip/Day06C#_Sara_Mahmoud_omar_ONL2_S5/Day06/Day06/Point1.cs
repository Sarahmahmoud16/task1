﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day06;
public struct Point1
{
    public int X { get; set; }
    public int Y { get; set; }

    // Overloaded constructors
    public Point1(int x)
    {
        X = x;
        Y = 0;
    }

    public Point1(int x, int y)
    {
        X = x;
        Y = y;
    }
}

 


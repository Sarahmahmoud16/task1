﻿
namespace Day06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Test ponint
            Point p1 = new Point();
            Point p2 = new Point(5, 10);
            Console.WriteLine(p1); // Output: (0, 0)
            Console.WriteLine(p2); // Output: (5, 10)

            // Accessing attributes
            TypeA obj = new TypeA();
            obj.PrintValues();  // F is private, only accessible here
            Console.WriteLine(obj.H);  // Public, accessible anywhere
                                       // Console.WriteLine(obj.G);  // Accessible within the same assembly


            // Test program
            Employee1 emp = new Employee1();
            emp.SetName("Alice");
            emp.SetSalary(50000);
            Console.WriteLine($"Name: {emp.GetName()}, Salary: {emp.GetSalary()}");

            // Test program
            Point1 p3 = new Point1(5);
            Point1 p4 = new Point1(5, 10);
            Console.WriteLine(p3); // Output: (5, 0)
            Console.WriteLine(p4); // Output: (5, 10)

        }
    }
}

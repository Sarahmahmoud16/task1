﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day06;
public class TypeA
{
    private int F = 10;
    internal int G = 20;
    public int H = 30;

    public void PrintValues()
    {
        Console.WriteLine($"F: {F}, G: {G}, H: {H}");
    }
}

 

